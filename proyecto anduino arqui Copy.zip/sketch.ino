/*
 * AutoGreen - Sistema de Monitoreo y Control de Invernadero
 * Arquitectura de Computadoras I
 * 
 * Sensores simulados internamente para demostración
 * 
 * Actuadores:
 *   - Ventilador: pin 9
 *   - Bomba de riego: pin 10
 *   - Calefactor (LED amarillo): pin 11
 *   - Luz auxiliar (LED blanco): pin 12
 */

#define PIN_VENTILADOR 9
#define PIN_BOMBA 10
#define PIN_CALEFACTOR 11
#define PIN_LUZ_AUX 12

// Variables simuladas
float temperatura = 25.0;
int humedadSuelo = 60;
int luminosidad = 5000;

int paso = 0;
unsigned long tiempoAnterior = 0;

void setup() {
  Serial.begin(9600);
  
  pinMode(PIN_VENTILADOR, OUTPUT);
  pinMode(PIN_BOMBA, OUTPUT);
  pinMode(PIN_CALEFACTOR, OUTPUT);
  pinMode(PIN_LUZ_AUX, OUTPUT);
  
  digitalWrite(PIN_VENTILADOR, LOW);
  digitalWrite(PIN_BOMBA, LOW);
  digitalWrite(PIN_CALEFACTOR, LOW);
  digitalWrite(PIN_LUZ_AUX, LOW);
  
  Serial.println("=====================================");
  Serial.println("     AutoGreen - Invernadero Inteligente");
  Serial.println("=====================================");
  Serial.println("Sistema iniciado correctamente");
  Serial.println("");
  Serial.println("Demostracion de funcionalidades:");
  Serial.println("(Cambia automaticamente cada 10 segundos)");
  Serial.println("=====================================");
  delay(2000);
}

void loop() {
  unsigned long ahora = millis();
  
  // Cambiar condiciones cada 10 segundos
  if (ahora - tiempoAnterior > 10000) {
    tiempoAnterior = ahora;
    paso++;
    
    // Ciclo de 5 pasos
    switch(paso % 5) {
      case 1:
        // PASO 1: Temperatura alta > 30°C
        temperatura = 35.0;
        humedadSuelo = 60;
        luminosidad = 5000;
        Serial.println("");
        Serial.println(">>> ESCENARIO 1: TEMPERATURA ALTA (35°C)");
        Serial.println(">>> El VENTILADOR debe activarse");
        break;
        
      case 2:
        // PASO 2: Temperatura baja < 15°C
        temperatura = 10.0;
        humedadSuelo = 60;
        luminosidad = 5000;
        Serial.println("");
        Serial.println(">>> ESCENARIO 2: TEMPERATURA BAJA (10°C)");
        Serial.println(">>> El CALEFACTOR debe activarse");
        break;
        
      case 3:
        // PASO 3: Suelo seco < 40%
        temperatura = 25.0;
        humedadSuelo = 25;
        luminosidad = 5000;
        Serial.println("");
        Serial.println(">>> ESCENARIO 3: SUELO SECO (25%)");
        Serial.println(">>> La BOMBA DE RIEGO debe activarse");
        break;
        
      case 4:
        // PASO 4: Oscuridad < 200 lux
        temperatura = 25.0;
        humedadSuelo = 60;
        luminosidad = 100;
        Serial.println("");
        Serial.println(">>> ESCENARIO 4: POCA LUZ (100 lux)");
        Serial.println(">>> La LUZ AUXILIAR debe activarse");
        break;
        
      case 0:
        // PASO 0: Condiciones normales
        temperatura = 25.0;
        humedadSuelo = 60;
        luminosidad = 5000;
        Serial.println("");
        Serial.println(">>> ESCENARIO 5: CONDICIONES NORMALES");
        Serial.println(">>> Todos los actuadores deben estar APAGADOS");
        break;
    }
  }
  
  // ========== LÓGICA DE CONTROL AUTOMÁTICO ==========
  
  // Regla 1: Temperatura > 30°C → Ventilador ON
  if (temperatura > 30.0) {
    digitalWrite(PIN_VENTILADOR, HIGH);
  } else {
    digitalWrite(PIN_VENTILADOR, LOW);
  }
  
  // Regla 2: Temperatura < 15°C → Calefactor ON
  if (temperatura < 15.0) {
    digitalWrite(PIN_CALEFACTOR, HIGH);
  } else {
    digitalWrite(PIN_CALEFACTOR, LOW);
  }
  
  // Regla 3: Humedad suelo < 40% → Bomba ON
  if (humedadSuelo < 40) {
    digitalWrite(PIN_BOMBA, HIGH);
  } else {
    digitalWrite(PIN_BOMBA, LOW);
  }
  
  // Regla 4: Luminosidad < 200 lux → Luz auxiliar ON
  if (luminosidad < 200) {
    digitalWrite(PIN_LUZ_AUX, HIGH);
  } else {
    digitalWrite(PIN_LUZ_AUX, LOW);
  }
  
  // ========== MOSTRAR DATOS EN PANTALLA ==========
  
  Serial.println("-------------------------------------");
  Serial.print("| Temperatura: ");
  Serial.print(temperatura);
  Serial.println(" °C");
  
  Serial.print("| Humedad Suelo: ");
  Serial.print(humedadSuelo);
  Serial.println(" %");
  
  Serial.print("| Luminosidad: ");
  Serial.print(luminosidad);
  Serial.println(" lux");
  Serial.println("-------------------------------------");
  
  Serial.print("| Ventilador: ");
  Serial.println(digitalRead(PIN_VENTILADOR) ? "  ENCENDIDO" : "  APAGADO");
  
  Serial.print("| Bomba riego: ");
  Serial.println(digitalRead(PIN_BOMBA) ? "  ENCENDIDA" : "  APAGADA");
  
  Serial.print("| Calefactor: ");
  Serial.println(digitalRead(PIN_CALEFACTOR) ? "  ENCENDIDO" : "  APAGADO");
  
  Serial.print("| Luz auxiliar: ");
  Serial.println(digitalRead(PIN_LUZ_AUX) ? "  ENCENDIDA" : "  APAGADA");
  
  Serial.println("=====================================");
  
  delay(2000);
}